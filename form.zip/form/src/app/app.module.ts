import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule } from "@angular/forms";
import { AppComponent } from './app.component';
import { FormTdComponent } from './form-td/form-td.component';
import { FormRComponent } from './form-r/form-r.component';

@NgModule({
  declarations: [
    AppComponent,
    FormTdComponent,
    FormRComponent
  ],
  imports: [
    BrowserModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
