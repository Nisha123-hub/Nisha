export class Department {
    Id="";
    name="";
  }
  