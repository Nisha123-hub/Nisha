import { Component } from '@angular/core';
import { NgForm } from "@angular/forms";
import { Department } from "./Department";
@Component({
  selector: 'app-form-td',
  templateUrl: './form-td.component.html',
  styleUrls: ['./form-td.component.css']
})
export class FormTdComponent  {

    name="" ;
      mail= "";
      dep="";
    };
  
    department: Department[] = [
      { Id: 1, name= "Java" },
      { Id: 2, name="Android" },
      { Id: 3, name= "MainFrame" },
      { Id: 4, name= "Cloud" }
    ];
  
    getData(dForm: NgForm): void {
      console.log(dForm.value);
    }
  }
      

 

