import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-r',
  templateUrl: './form-r.component.html',
  styleUrls: ['./form-r.component.css']
})
export class FormRComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
