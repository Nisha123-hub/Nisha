import { Component } from '@angular/core';
import { department} from "./department" ;

@Component({
  selector: 'app-form-td',
  templateUrl: './form-td.component.html',
  styleUrls: ['./form-td.component.css']
})
export class FormTDComponent {
 
 fn: string=""; 
ln: string="";
email:string="";

dep: department[]=[
  {id:1 ,dname:"Java"},
  {id:2 ,dname:"Angular"},
  {id:3 ,dname:"CSS"},
  {id:4 ,dname:"Python"},
];
  } 