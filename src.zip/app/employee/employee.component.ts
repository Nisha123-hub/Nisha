import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee ',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
Name: string="Nisha Singh";
ID:number=123;
onclick(){
  alert(" Employee info");
}
  

  constructor() { }

  ngOnInit(): void {
  }

}
